<?php

include("header.php");
?>
  
  
 <?php 

 $del=$_GET['srno'];
echo $del;
 require_once('dcon.php'); mysql_select_db($database_localhost,$localhost);
   
    $query_search = "delete from btech where id='$del'";
$query_exec = mysql_query($query_search) or die(mysql_error());
$rows = mysql_num_rows($query_exec);
//echo $rows;
 if($rows == 0) { 
 echo "<div><h1>Deleted Successfully</h1><h2>&nbsp &nbsp You'll be Redirected shortly<h2></div>";
header( "refresh:3;url=webAdminBtechNoticeDelete.php?pid=NULL" );
 }
 else  {
    echo "<div><h1>Deletion Failed</h1><h2>&nbsp &nbsp You'll be Redirected shortly<h2></div>";
header( "refresh:3;url=webAdminBtechNoticeDelete.php?pid=NULL" );
}
 
 
?> 