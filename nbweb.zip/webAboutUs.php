
<?php

include("header.php");
?>
    <div id="home-sec">

   
    <div class="container" id="home" >
        <div class="row text-center g-pad-bottom">
            <div class="col-md-12">
                 <span class="head-main">ABOUT US</span>
              
            </div>
        </div>


        <div class="row text-center">
            <div class="col-md-4  col-sm-4">
               
                            <h4>Sirda Group of Institutions</h4>
							<font color="black">
                          NH21, Naulakha, Himachal Pradesh 175021<br>
<i class="fa fa-phone"></i>&nbsp &nbsp  01907 262 512<br>
<i class="fa fa-envelope"></i>&nbsp &nbsp  sirda.edu@gmail.com
	</font>
                           
                </div>
             <div class="col-md-4  col-sm-4">
                
                            <h4>SIRDA NoticeBoard </h4>
                         <font color="black">
The vision of the website is to notify all the students to get notices updates from college on SIRDA noticeboard website at anytime and anywhere which is beneficial to student, teacher and management. 						 </font>
                           
                </div>
            <div class="col-md-4  col-sm-4" color="#fff">
                                    <h4>Developers</h4>
									<font color="black">
							<b>Jitender Kumar</b><br>
							<i>jitender9410@gmail.com</i><br><br>
							<b>Kamal Kant</b><br>
							<i>kkchaudhaty11@gmail.com</i><br><br>
							<b>Shubham Verma</b><br>
							<i>shubham80621@gmail.com</i><br><br>
							<b>Vipin Kumar</b><br>
							<i>vickeyvipin.92@gmail.com</i><br><br>
							<b>Yogesh Dogra</b><br>
							<i>dogra.yogesh77@gmail.com</i><br><br>
				</font>
                           
                           
                </div>
            </div>
        
    </div>
         </div>
    
    <!--END HOME SECTION-->
  
   

<?php

include("footer.php");
?>
