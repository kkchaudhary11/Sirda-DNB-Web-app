
<?php

include("header.php");
?>
    <div id="home-sec">

   
    <div class="container" id="home" >
        <div class="row text-center g-pad-bottom">
		<div class="col-md-4 col-sm-4" >
                 
               </div>
            <div class="col-md-4 col-sm-4" >
                 <span class="head-main" >ADMIN</span>
               </div>
				<div class="col-md-4 col-sm-4">
				<div class=mybutton>
		<form action="logout.php">
    <input type="submit" value="LOG OUT">
		</form>
		</div>
        </div>
        </div>


        <div class="row text-center">
            <div class="col-md-4  col-sm-4">
                 <a href="webAdminBtechNoticeUpdate.php"><i class="fa fa-edit faa-vertical animated icon-round bk-color-red"></i></a>
                            <h4>Create</h4>
                          
                           
                </div>
             <div class="col-md-4  col-sm-4">
                <a href="webAdminBtechNoticeDelete.php?pid=NULL"> <i class="fa fa-trash-o faa-ring animated icon-round bk-color-red"></i></a>
                            <h4>Delete</h4>
                         
                           
                </div>
            <div class="col-md-4  col-sm-4">
                  <a href="webViewSuggestion.php"> <i class="fa fa-thumbs-up  faa-shake animated icon-round bk-color-red"></i></a>
                            <h4>View Suggestion</h4>
                           
                           
                </div>
            </div>
        
    </div>
         </div>
    
    <!--END HOME SECTION-->
  
   

<?php

include("footer.php");
?>
