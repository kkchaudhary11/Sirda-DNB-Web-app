  <!--FOOTER SECTION -->
    <div id="footer">
    <div class="container" id="ft" >
	
	<div class="row text-center">
            <div class="col-md-4  col-sm-4">
                 <a href="https://play.google.com/store/apps/details?id=in.sirda.sirdanb&utm_source=global_co&utm_medium=prtnr&utm_content=Mar2515&utm_campaign=PartBadge&pcampaignid=MKT-AC-global-none-all-co-pr-py-PartBadges-Oct1515-1"><img alt="Get it on Google Play" src="https://play.google.com/intl/en_us/badges/images/apps/en-play-badge.png" height="50px" width="170px"/></a>
             
                           
                </div>
			
             
             <div class="col-md-4  col-sm-4">
                <a href="https://www.facebook.com/sirda.institute/?ref=eyJzaWQiOiIwLjA4MzUyMjY0NDExNzE1MjYiLCJxcyI6IkpUVkNKVEl5VTBsU1JFRWxNakJIY205MWNDVXlNRzltSlRJd1NXNXpkR2wwZFhScGIyNXpKVEl5SlRWRSIsImd2IjoiOWQ3ZGVjNjU5YjJlNmQyZGE0NjczNTVjYWJlZTNjYTE2MjQ2NWFjZCJ9">
				<span class="fa-stack fa-2x">
  <i class="fa fa-circle fa-stack-2x"></i>
  <i class="fa fa-facebook fa-stack-1x fa-inverse"></i>
</span></a>                                 
  
                         
                           
                </div>
            <div class="col-md-4  col-sm-4">
			<br>
                 <a href="http://sirda.in/" style="margin-right:5px;"> Sirda.in </a>

        © 2008-2016 | All Right Reserved  
                      </div>     
                      

    </div>

  
    <!-- END FOOTER SECTION -->

    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="assets/plugins/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP CORE SCRIPT   -->
    <script src="assets/plugins/bootstrap.js"></script>
  
    <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>

</body>
</html>