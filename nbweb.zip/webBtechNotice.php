

<?php

include("header.php");
?>
    
<div id="home-sec">
 <div class="container" id="home" >
        <div class="row text-center">
  
<!----------------------fform--------------------------------------------->
 <div class="container1" >
	<section id="content" >
			<font color="grey" size="8px"><b>NOTICES</b></font>
<div  style="color:grey; text-align:left; padding-left:5px; padding-right:5px;">
      <!-------------php code--------------->
       <?php

$form=$_GET['pid'];
  require_once('dcon.php');       
   mysql_select_db($database_localhost,$localhost);
   
if($form=='NULL')
{          $query="SELECT * FROM btech ORDER BY id DESC LIMIT 10";
               
}
else
{
$form=$form-10;
$query="SELECT * FROM nbdata WHERE(id<='$form')ORDER BY id DESC LIMIT 10 ";

}


                   $result=mysql_query($query);                          
                 echo "<hr>";
                 while($row = mysql_fetch_assoc($result))
                    {
						$srno = $row['id'];
						$hash = "#" . $srno;
						
						$time=$row["time"];
						$date=$row["date"];
						$update_time = $date." ".$time;
		
		$timeago=time_elapsed_string($update_time, false);
                     echo "<a href=uploads/".$row['name']." style=' text-decoration: none;'>
					 <div><div style='float:left; width:75%; overflow:hidden;'><font color='#b71c1c' size='4px'><b>".$row['sub']."</b></font><br><font color='grey'>"
					 .$row['descr']."</font><br>"
					 .$row['branch']
					 ."</div><div style='text-align:right; overflow:hidden;'><font color='grey' size='2px'><b>"
					 .$hash."</b></font><br><br><font color='black' size='2px'>"
					 .$timeago."</font></div></div> </a>";
					 
                     echo"<hr>";

                       } 


                      echo"</table>";


if($form=='NULL')
{          $query="SELECT * FROM btech ORDER BY id DESC LIMIT 1";
               
}
else
{
$form=$form-10;
$query="SELECT * FROM btech WHERE id<='$form'  ORDER BY id DESC LIMIT 1 ";

}

               $result=mysql_query($query);



                 while($row = mysql_fetch_assoc($result))
                    {
                  echo"   <form action='webBtechNotice.php' method='get'>
		
			<input type='hidden' name='pid' value='".$row['id']."'>
				<input type='submit' value='Older'/>
				
			
		</form>";}

           ?>


</div>			
				
		
	</section><!-- content -->
</div><!-- container -->


<!-----------------------------------------------------end form----------------------------->








            </div>
        
    </div>
         </div>
    
    <!--END HOME SECTION-->
  
   <br><br>

<?php

include("footer.php");
?>


<?php
function time_elapsed_string($datetime, $full = false) {
	date_default_timezone_set("Asia/Kolkata");
    $now = new DateTime;
	
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;

    $string = array(
        'y' => 'year',
        'm' => 'month',
        'w' => 'week',
        'd' => 'day',
        'h' => 'hour',
        'i' => 'minute',
        's' => 'second',
    );
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
        } else {
            unset($string[$k]);
        }
    }

    if (!$full) $string = array_slice($string, 0, 1);
    return $string ? implode(', ', $string) . ' ago' : 'just now';
}
?>
